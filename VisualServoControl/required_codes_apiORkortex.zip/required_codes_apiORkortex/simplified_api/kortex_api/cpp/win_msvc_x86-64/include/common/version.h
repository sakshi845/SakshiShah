#ifndef VERSION_H
#define VERSION_H

#define PROJECT_NAME "KortexApiCpp"
#define PROJECT_VER  "2.2.0"
#define PROJECT_VER_MAJOR "2"
#define PROJECT_VER_MINOR "2"
#define PTOJECT_VER_PATCH "0"

#endif //VERSION_H
