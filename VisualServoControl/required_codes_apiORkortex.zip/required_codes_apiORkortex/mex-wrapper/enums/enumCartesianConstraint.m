classdef enumCartesianConstraint < int32
    enumeration
        no_constraint (0)
        duration (1)
        cartesian_velocity (2)
    end
end
