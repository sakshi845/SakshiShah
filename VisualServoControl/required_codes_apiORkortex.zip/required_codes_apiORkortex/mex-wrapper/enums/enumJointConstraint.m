classdef enumJointConstraint < int32
    enumeration
        no_constraint (0)
        duration (1)
        joint_velocity (2)
    end
end
